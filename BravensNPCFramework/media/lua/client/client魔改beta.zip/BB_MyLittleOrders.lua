-- **************************************************
-- ██████  ██████   █████  ██    ██ ███████ ███    ██ 
-- ██   ██ ██   ██ ██   ██ ██    ██ ██      ████   ██ 
-- ██████  ██████  ███████ ██    ██ █████   ██ ██  ██ 
-- ██   ██ ██   ██ ██   ██  ██  ██  ██      ██  ██ ██ 
-- ██████  ██   ██ ██   ██   ████   ███████ ██   ████
-- **************************************************
-- ** Seek Excellence! Employ ME, not my Copycats. **
-- **************************************************

MyLittleOrders = {}
local managedNPCs = {}

--- Subscribe to this Module to handle NPC orders (Equip/Unequip, Stop/Follow, etc).
---@param newData table The variable containing the NPC's persistent data.
MyLittleOrders.ManageNPC = function(newData)
    table.insert(managedNPCs, newData)
end

MyLittleOrders.RemoveNPC = function(npcID)
    for i, npcData in ipairs(managedNPCs) do
        if npcID == npcData.uniqueID then
            table.remove(managedNPCs, i)
            break
        end
    end
end

local function TryEquipItem(npcData, item, equipType, context)

    if ZombRand(1, 10) <= 4 then
        local randSpeech = 1
		if item:IsWeapon() then
			randSpeech = ZombRand(1,4)
			MyLittleSpeech.Say(npcData, "Equip_Weapon_" .. randSpeech)
		end
    end

	local primaryHandItem = npcData.npc:getPrimaryHandItem()
	if primaryHandItem then
		primaryHandItem:getModData().equippedByBravenNPC = nil
		npcData.npc:setPrimaryHandItem(nil)
	end

	local secondaryHandItem = npcData.npc:getSecondaryHandItem()
	if secondaryHandItem then
		secondaryHandItem:getModData().equippedByBravenNPC = nil
		npcData.npc:setSecondaryHandItem(nil)
	end

	if equipType == "Primary" then
		npcData.npc:setPrimaryHandItem(item)
	elseif equipType == "Secondary" then
		npcData.npc:setSecondaryHandItem(item)
	elseif equipType == "BothHands" or item:isRequiresEquippedBothHands() then
		npcData.npc:setPrimaryHandItem(item)
		npcData.npc:setSecondaryHandItem(item)
	end

	npcData.weaponIsRanged = item:isRanged()
	item:getModData().equippedByBravenNPC = true
	context:closeAll()
end

local function TryEquipClothing(npcData, items, time, context)
    for _, item in ipairs(items) do

        local location = nil
		if not instanceof(item, "InventoryContainer") then
			location = item:getBodyLocation()
		else
			location = item:canBeEquipped()
		end

		local wornItem = npcData.npc:getWornItem(location)
        if wornItem then
            if wornItem ~= item then
                ISTimedActionQueue.add(ISUnequipAction:new(npcData.npc, wornItem, time))
                wornItem:getModData().equippedByBravenNPC = nil
            else
                context:closeAll()
                return
            end
        end

        ISTimedActionQueue.add(ISWearClothing:new(npcData.npc, item, time))
        item:getModData().equippedByBravenNPC = true
    end

    if ZombRand(1, 10) <= 4 then
        local randSpeech = ZombRand(1,4)
		MyLittleSpeech.Say(npcData, "Equip_Clothing_" .. randSpeech)
    end

    context:closeAll()
end

local function TryUnequipItems(npc, items, time, context)
    for _, item in ipairs(items) do
        ISTimedActionQueue.add(ISUnequipAction:new(npc, item, time))
        item:getModData().equippedByBravenNPC = nil
    end
	context:closeAll()
end

local function setCombatStance(npcData, newState, context)
	MyLittleUtils.DelayFunction(function() npcData.npc:playEmote(npcData.acknowledgeEmote) end, ZombRand(20, 100))
	MyLittleUtils.AcknowledgeAction(npcData)
	MyLittleUtils.SetCombatStance(npcData, newState)
	context:closeAll()

	local randSpeech = -1

	if ZombRand(1, 10) <= 4 then
		randSpeech = ZombRand(1,4)
	end

	if newState == "Offensive" then
		if randSpeech ~= -1 then
			MyLittleSpeech.Say(npcData, "CombatMode_Offensive_" .. randSpeech)
		end
	elseif newState == "Balanced" then
		if randSpeech ~= -1 then
			MyLittleSpeech.Say(npcData, "CombatMode_Balanced_" .. randSpeech)
		end
    else
		npcData.target = getPlayer()
		if randSpeech ~= -1 then
			MyLittleSpeech.Say(npcData, "CombatMode_Defensive_" .. randSpeech)
		end
	end
end

local addEquipWeaponMenu = function(npcData, item, context, equipSubmenu)
	local equipTypeOption = equipSubmenu:addOption(item:getName())
	local equipTypeSubmenu = ISContextMenu:getNew(context)
	context:addSubMenu(equipTypeOption, equipTypeSubmenu)
	equipTypeSubmenu:addOption(getText("ContextMenu_Equip_Primary"), npcData, TryEquipItem, item, "Primary", context)
	equipTypeSubmenu:addOption(getText("ContextMenu_Equip_Secondary"), npcData, TryEquipItem, item, "Secondary", context)
	equipTypeSubmenu:addOption(getText("ContextMenu_Equip_Two_Hands"), npcData, TryEquipItem, item, "BothHands", context)
end

local lockMovement = function(npcData, newState, context)
	MyLittleUtils.DelayFunction(function() npcData.npc:playEmote(npcData.acknowledgeEmote) end, ZombRand(20, 100))
	MyLittleUtils.AcknowledgeAction(npcData)
	MyLittleUtils.LockMovement(npcData, newState)
	context:closeAll()
end

local onWorldContextMenu = function(player, context, worldobjects, test)

    if clickedPlayer then

        local clickedNPCData = nil
        for _, npcData in ipairs(managedNPCs) do
            if clickedPlayer == npcData.npc then

                clickedNPCData = npcData
                local npcInv = clickedNPCData.npc:getInventory()

                ------------------------=( ORDER MENU )=------------------------
                local orderOption = context:addOptionOnTop(getText("ContextMenu_Orders"))
                local orderSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(orderOption, orderSubmenu)
                ----------------------------------------------------------------

                ------------------------=( EQUIP MENU )=------------------------
                local equipOption = orderSubmenu:addOption(getText("ContextMenu_Equip"))
                local equipSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(equipOption, equipSubmenu)

                local equipWeaponOption = equipSubmenu:addOption(getText("IGUI_ItemCat_Weapon"))
                local equipWeaponSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(equipWeaponOption, equipWeaponSubmenu)

                local equipClothingOption = equipSubmenu:addOption(getText("IGUI_ItemCat_Clothing"))
                local equipClothingSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(equipClothingOption, equipClothingSubmenu)

                ------------------------=( UNEQUIP MENU )=------------------------
                local unequipOption = orderSubmenu:addOption(getText("ContextMenu_Unequip"))
                local unequipSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(unequipOption, unequipSubmenu)

                local unequipWeaponOption = unequipSubmenu:addOption(getText("IGUI_ItemCat_Weapon"))
                local unequipWeaponSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(unequipWeaponOption, unequipWeaponSubmenu)

                local unequipClothingOption = unequipSubmenu:addOption(getText("IGUI_ItemCat_Clothing"))
                local unequipClothingSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(unequipClothingOption, unequipClothingSubmenu)

                ------------------------=( LISTS )=------------------------
                local allEquippedClothing = {}
                local allUnequippedClothing = {}
                local looseItemsBraven = {}
                local bravenItems = npcInv:getItems()

                for i=0, bravenItems:size() - 1 do

                    local item = npcInv:getItems():get(i)
                    if item:getDisplayCategory() ~= "Wound" then

                        if not item:isEquipped() and item:getAttachedSlot() == -1 then
                            ------------------------=( EQUIP OPTIONS )=------------------------
                            if item:IsClothing() or instanceof(item, "InventoryContainer") then
                                equipClothingSubmenu:addOption(item:getName(), clickedNPCData, TryEquipClothing,  { item }, 50, context)
                                table.insert(allEquippedClothing, item)
                            end

                            table.insert(looseItemsBraven, item)
                        else ------------------------=( UN-EQUIP OPTIONS )=------------------------
                            if item:IsWeapon() then
                                unequipWeaponSubmenu:addOption(item:getName(), clickedNPCData.npc, TryUnequipItems, { item }, 50, context)
                            end

                            if item:IsClothing() or instanceof(item, "InventoryContainer") then
                                unequipClothingSubmenu:addOption(item:getName(), clickedNPCData.npc, TryUnequipItems, { item }, 50, context)
                                table.insert(allUnequippedClothing, item)
                            end
                        end

                        ------------------------=( EQUIP WEAPON OPTIONS )=------------------------
                        if item:IsWeapon() then
                            addEquipWeaponMenu(clickedNPCData, item, context, equipWeaponSubmenu)
                        end
                    end
                end

                ------------------------=( LIST OPTIONS )=------------------------
                if #allEquippedClothing > 1 then
                    equipClothingSubmenu:addOptionOnTop(getText("ContextMenu_All"), clickedNPCData, TryEquipClothing, allEquippedClothing, 50, context)
                end

                if #allUnequippedClothing > 1 then
                    unequipClothingSubmenu:addOptionOnTop(getText("ContextMenu_All"), clickedNPCData.npc, TryUnequipItems, allUnequippedClothing, 50, context)
                end

                ------------------------=( STANCE MENU )=------------------------
                local stanceOption = orderSubmenu:addOption(getText("ContextMenu_CombatStance"))
                local stanceSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(stanceOption, stanceSubmenu)
                stanceSubmenu:addOption(getText("ContextMenu_Offensive"), clickedNPCData, setCombatStance, "Offensive", context)
                stanceSubmenu:addOption(getText("ContextMenu_Balanced"), clickedNPCData, setCombatStance, "Balanced", context)
                stanceSubmenu:addOption(getText("ContextMenu_Defensive"), clickedNPCData, setCombatStance, "Defensive", context)

                ------------------------=( SUB-ORDERS MENU )=------------------------
                orderSubmenu:addOption(getText("IGUI_Emote_Stop"), clickedNPCData,lockMovement, true, context)
                orderSubmenu:addOption(getText("IGUI_Emote_FollowMe"), clickedNPCData, lockMovement, false, context)
            end
        end
    end

    return context
end

Events.OnFillWorldObjectContextMenu.Add(onWorldContextMenu)
