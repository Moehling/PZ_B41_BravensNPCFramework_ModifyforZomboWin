-- **************************************************
-- ██████  ██████   █████  ██    ██ ███████ ███    ██ 
-- ██   ██ ██   ██ ██   ██ ██    ██ ██      ████   ██ 
-- ██████  ██████  ███████ ██    ██ █████   ██ ██  ██ 
-- ██   ██ ██   ██ ██   ██  ██  ██  ██      ██  ██ ██ 
-- ██████  ██   ██ ██   ██   ████   ███████ ██   ████
-- **************************************************
-- ** Seek Excellence! Employ ME, not my Copycats. **
-- **************************************************

MyLittleTrading = {}
local managedNPCs = {}

--- Subscribe to this Module to handle NPC trading (Take and Give items).
---@param newData table The variable containing the NPC's persistent data.
MyLittleTrading.ManageNPC = function(newData)
    table.insert(managedNPCs, newData)
end

MyLittleTrading.RemoveNPC = function(npcID)
    for i, npcData in ipairs(managedNPCs) do
        if npcID == npcData.uniqueID then
            table.remove(managedNPCs, i)
            break
        end
    end
end

local function walkToNPC(playerObj, npc)
    if MyLittleUtils.DistanceBetween(npc, playerObj) > 2 then
        local npcSq = npc:getSquare()
        local targetSq = AdjacentFreeTileFinder.FindClosest(npcSq, playerObj) or npcSq
        ISTimedActionQueue.add(ISPathFindAction:pathToLocationF(playerObj, targetSq:getX(), targetSq:getY(), targetSq:getZ()))
    end
end

local function getItemsOfType(mainContainer, itemType, mustBeUnequipped)
	local randomWeirdVar = mainContainer:getAllTypeRecurse(itemType)
	local itemList = {}

	for i=1,randomWeirdVar:size() do
		local item = randomWeirdVar:get(i-1)
		if not mustBeUnequipped then
			table.insert(itemList, item)
		elseif not item:isEquipped() and item:getAttachedSlot() == -1 then
			table.insert(itemList, item)
		end
	end

	return itemList
end

local function handleSingleTrade(playerObj, npcData, tradeType, item, context)
    if tradeType == "Give" then
        ISInventoryPaneContextMenu.transferIfNeeded(playerObj, item)
        if item:isEquipped() then ISTimedActionQueue.add(ISUnequipAction:new(playerObj, item, 50)) end
    else
        ISInventoryPaneContextMenu.transferIfNeeded(npcData.npc, item)
    end

    ISTimedActionQueue.add(MyLittleTimedActions:TradeWithNPC(npcData, playerObj, tradeType, item))
    MyLittleUtils.LockMovement(npcData, false)
    context:closeAll()
end

local function tryTradeWithNPC(playerObj, npcData, tradeType, item, quantity, context, dontWalk)

	if not dontWalk then
		walkToNPC(playerObj, npcData.npc)
	end

	if ZombRand(1, 10) <= 4 then
		local randSpeech = ZombRand(1,6)
		MyLittleSpeech.Say(npcData, "Trading_" .. randSpeech)
	end

    if type(item) == "table" then
        for i, singleItem in ipairs(item) do
			if i <= quantity then
				handleSingleTrade(playerObj, npcData, tradeType, singleItem, context)
			else
				return
			end
        end
    else
        handleSingleTrade(playerObj, npcData, tradeType, item, context)
    end
end

local function tryTradeEverything(playerObj, npcData, characterInv, tradeType, items, context)
	walkToNPC(playerObj, npcData.npc)

	for _, item in ipairs(items) do
		if not item:isEquipped() and item:getAttachedSlot() == -1 then
			local itemList = getItemsOfType(characterInv, item:getType(), true)
			tryTradeWithNPC(playerObj, npcData, tradeType, item, #itemList, context, true)
		end
	end
end

local function isInList(value, list)
    for _, v in ipairs(list) do
        if v == value then
            return true
        end
    end
    return false
end

local addInvWeightTooltip = function(option, isRed, currWeight, totalWeight, extraWeight)
    local tooltip = ISToolTip:new()
    tooltip:initialise()
    tooltip:setVisible(false)
    option.toolTip = tooltip

    local description = getText("IGUI_char_Weight") .. " " .. MyLittleUtils.RoundToDecimalPlaces(currWeight, 2)
    if extraWeight then
        description = description .. " (+ " .. MyLittleUtils.RoundToDecimalPlaces(extraWeight, 2)  .. ")"
    end

    description = description .. " / " .. MyLittleUtils.RoundToDecimalPlaces(totalWeight, 2)

    if (isRed) then
        description = "<RGB:1,0.2,0.2>" .. description
    end

    tooltip.description = description
end

local checkIfOverburdened = function(option, itemWeight, currCharacterWeight, maxCharacterWeight)
	if currCharacterWeight + itemWeight > maxCharacterWeight then
		option.notAvailable = true
		addInvWeightTooltip(option, true, currCharacterWeight, maxCharacterWeight, itemWeight)
	else
		addInvWeightTooltip(option, false, currCharacterWeight, maxCharacterWeight, itemWeight)
	end
end

local function addBulkMenu(npcData, tradeType, submenu, context, items, itemCount, itemWeight, character, currCharacterWeight, maxCharacterWeight)
    local bulkGiveOption = submenu:addOption(items[1]:getName())
    local bulkGiveSubmenu = ISContextMenu:getNew(context)
    context:addSubMenu(bulkGiveOption, bulkGiveSubmenu)

    local amounts = {100, 50, 25, 10, 5, 4, 3, 2, 1}
    for _, count in ipairs(amounts) do
        if itemCount >= count then
            local option = bulkGiveSubmenu:addOption(tostring(count), character, tryTradeWithNPC, npcData, tradeType, items, count, context)
            checkIfOverburdened(option, itemWeight * count, currCharacterWeight, maxCharacterWeight)
        end
    end

	local allOption = bulkGiveSubmenu:addOptionOnTop(getText("ContextMenu_All"), character, tryTradeWithNPC, npcData, tradeType, items, itemCount, context)
	checkIfOverburdened(allOption, itemWeight * itemCount, currCharacterWeight, maxCharacterWeight)
end

local function getActualMaxCapacity(charInventory, character)
	local maxPersonCapacity = charInventory:getEffectiveCapacity(character)
	local maxBagCapacity = 0

	for i=0, charInventory:getItems():size() - 1 do
		local item = charInventory:getItems():get(i)
		if item:isEquipped() and instanceof(item, "InventoryContainer") then
			maxBagCapacity = maxBagCapacity + item:getEffectiveCapacity(character)
		end
	end

	local actualMaxCapacity = maxPersonCapacity + maxBagCapacity
	return actualMaxCapacity
end

local onWorldContextMenu = function(player, context, worldobjects, test)

    if clickedPlayer then

        local clickedNPCData = nil
        for _, npcData in ipairs(managedNPCs) do
            if clickedPlayer == npcData.npc then

                clickedNPCData = npcData

                local playerObj = getSpecificPlayer(player)
                local playerInv = playerObj:getInventory()
                local currPlayerWeight = playerInv:getCapacityWeight()
                local maxPlayerWeight = playerInv:getEffectiveCapacity(playerObj)

                local npcInv = clickedNPCData.npc:getInventory()
                local currBravenWeight = npcInv:getCapacityWeight()
                local maxBravenWeight = getActualMaxCapacity(npcInv, clickedNPCData.npc)
                local listedItems = { "KeyRing" }

                ------------------------=( TRADE MENU )=------------------------
                local tradeOption = context:addOptionOnTop(getText("ContextMenu_Trade", clickedNPCData.npc:getFullName()))
                local tradeSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(tradeOption, tradeSubmenu)
                ----------------------------------------------------------------

                ------------------------=( STATUS MENU )=------------------------
                local statusOption = context:addOptionOnTop(getText("UI_Scoreboard_Stats"))
                local statusSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(statusOption, statusSubmenu)
                local invStatsOption = statusSubmenu:addOption(getText("IGUI_Controller_Inventory"))
                addInvWeightTooltip(invStatsOption, false, currBravenWeight, maxBravenWeight, nil)
                ----------------------------------------------------------------

                ------------------------=( GIVE ITEMS )=------------------------
                local giveOption = tradeSubmenu:addOption(getText("ContextMenu_Give"))
                local giveSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(giveOption, giveSubmenu)

                local looseItemsPlayer = {}
                local playerItems = playerInv:getItems()

                for i = 0, playerItems:size() - 1 do
                    local item = playerItems:get(i)
                    if not item:isEquipped() and item:getAttachedSlot() == -1 then
                        local itemType = item:getType()

                        if not (instanceof(item, "InventoryContainer") and item:getInventoryWeight() > 0) then
                            if not isInList(itemType, listedItems) then
                                local itemList = getItemsOfType(playerInv, itemType, true)
                                local itemWeight = item:getWeight()

                                if #itemList < 2 then
                                    local option = giveSubmenu:addOption(item:getName(), playerObj, tryTradeWithNPC, clickedNPCData, "Give", item, 1, context)
                                    checkIfOverburdened(option, itemWeight, currBravenWeight, maxBravenWeight)
                                else
                                    addBulkMenu(clickedNPCData, "Give", giveSubmenu, context, itemList, #itemList, itemWeight, playerObj, currBravenWeight, maxBravenWeight)
                                end

                                table.insert(listedItems, itemType)
                            end
                        end

                        if itemType ~= "KeyRing" then
                            table.insert(looseItemsPlayer, item)
                        end
                    end
                end

                ------------------------=( LIST OPTIONS )=------------------------
                if #looseItemsPlayer > 1 then
                    giveSubmenu:addOptionOnTop(getText("ContextMenu_All"), playerObj, tryTradeEverything, clickedNPCData, playerInv, "Give", looseItemsPlayer, context)
                end

                ------------------------=( TAKE ITEMS )=------------------------
                local takeOption = tradeSubmenu:addOption(getText("ContextMenu_Take"))
                local takeSubmenu = ISContextMenu:getNew(context)
                context:addSubMenu(takeOption, takeSubmenu)
                listedItems = { }

                ------------------------=( LISTS )=------------------------
                local looseItemsNPC = {}
                local NPCItems = npcInv:getItems()

                for i=0, NPCItems:size() - 1 do
                    local item = npcInv:getItems():get(i)

                    ------------------------=( TAKE OPTIONS )=------------------------
                    if item:getDisplayCategory() ~= "Wound" and not item:isEquipped() and item:getAttachedSlot() == -1 then
                        local itemType = item:getType()

                        if not isInList(itemType, listedItems) then
                            local itemList = getItemsOfType(npcInv, itemType, true)
                            local itemWeight = item:getWeight()

                            if #itemList < 2 then
                                local option = takeSubmenu:addOption(item:getName(), playerObj, tryTradeWithNPC, clickedNPCData, "Take", item, 1, context)
                                checkIfOverburdened(option, itemWeight, currPlayerWeight, maxPlayerWeight)
                            else
                                addBulkMenu(clickedNPCData, "Take", takeSubmenu, context, itemList, #itemList, itemWeight, playerObj, currPlayerWeight, maxPlayerWeight)
                            end

                            table.insert(listedItems, itemType)
                        end

                        table.insert(looseItemsNPC, item)
                    end
                end

                ------------------------=( LIST OPTIONS )=------------------------
                if #looseItemsNPC > 1 then
                    takeSubmenu:addOptionOnTop(getText("ContextMenu_All"), playerObj, tryTradeEverything, clickedNPCData, npcInv, "Take", looseItemsNPC, context)
                end
            end
        end
    end

    return context
end

Events.OnFillWorldObjectContextMenu.Add(onWorldContextMenu)