-- **************************************************
-- ██████  ██████   █████  ██    ██ ███████ ███    ██ 
-- ██   ██ ██   ██ ██   ██ ██    ██ ██      ████   ██ 
-- ██████  ██████  ███████ ██    ██ █████   ██ ██  ██ 
-- ██   ██ ██   ██ ██   ██  ██  ██  ██      ██  ██ ██ 
-- ██████  ██   ██ ██   ██   ████   ███████ ██   ████
-- **************************************************
-- ** Seek Excellence! Employ ME, not my Copycats. **
-- **************************************************

MyLittleSave = {}
local managedNPCs = {}

--- Subscribe to this Module to save the Inventory of an NPC in a custom stash.
---@param newData table The variable containing the NPC's persistent data.
MyLittleSave.ManageNPC = function(newData)
    table.insert(managedNPCs, newData)
end

MyLittleSave.RemoveNPC = function(npcID)
    for i, npcData in ipairs(managedNPCs) do
        if npcID == npcData.uniqueID then
            table.remove(managedNPCs, i)
            break
        end
    end
end


local saveStash = function(npcData)
    if npcData.FirstStart == false then
        local stashSq = MyLittleUtils.FetchRandomSquare(MyLittleUtils.playerObj:getSquare())
        if stashSq then
            npcData.stashCoordsX = stashSq:getX()
            npcData.stashCoordsY = stashSq:getY()
            local stash = IsoObject.new(getCell(), stashSq, "furniture_storage_02_29")
            if stash then
                stashSq:AddSpecialObject(stash)
                stash:getModData().isBravenNPCStash = true
                stash:transmitCompleteItemToClients()
                stash:transmitModData()

                local container = ItemContainer.new()
                stash:setContainer(container)

                local npcInv = npcData.npc:getInventory()
				
                local itemCount = npcInv:getItems():size()
                for i = itemCount - 1, 0, -1 do
                    local item = npcInv:getItems():get(i)
                    if item then
                        container:AddItem(item)
                    end
                end
            end
        end
    end
end


--- Saves the Stash location of every NPC, no file management needed.
MyLittleSave.OnSave = function(npc)
    -- if (MyLittleUtils.playerObj and MyLittleUtils.playerObj:getHoursSurvived() <= 0.3) then return end

    if not npc then
        for _, npcData in ipairs(managedNPCs) do
            npcData.npc:setZombiesDontAttack(false)
            npcData.npc:setInvisible(false)
            npcData.npc:setNoClip(true)
            npcData.npc:setGodMod(npcData.setGod)
            npcData.inknock = false
            saveStash(npcData)
        end
    else
        saveStash(npc)
    end

    print("SAVED INVENTORY! SHOW THIS IN BUG REPORTS IF NEEDED!")
end

local onMainMenuMouseDown = MainScreen.onMenuItemMouseDownMainMenu

MainScreen.onMenuItemMouseDownMainMenu = function(item, x, y)
    if MainScreen.instance.inGame == true and item.internal == "EXIT" then
        MyLittleSave.OnSave()
    end

    onMainMenuMouseDown(item, x, y)
end
-- 保存原函数
local originalOnConfirmQuitToDesktop = MainScreen.onConfirmQuitToDesktop

-- 劫持函数
MainScreen.onConfirmQuitToDesktop = function(self, button)
    -- 如果玩家点击了"YES"（确认退出）
    if button.internal == "YES" then
        -- 检查是否在游戏中（避免在菜单界面误保存）
        if MainScreen.instance and MainScreen.instance.inGame then
            MyLittleSave.OnSave()  -- 调用你的保存逻辑
        end
    end

    -- 调用原函数（确保原有的退出逻辑仍然执行）
    return originalOnConfirmQuitToDesktop(self, button)
end