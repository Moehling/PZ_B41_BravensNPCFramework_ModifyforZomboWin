-- **************************************************
-- ██████  ██████   █████  ██    ██ ███████ ███    ██ 
-- ██   ██ ██   ██ ██   ██ ██    ██ ██      ████   ██ 
-- ██████  ██████  ███████ ██    ██ █████   ██ ██  ██ 
-- ██   ██ ██   ██ ██   ██  ██  ██  ██      ██  ██ ██ 
-- ██████  ██   ██ ██   ██   ████   ███████ ██   ████
-- **************************************************
-- ** Seek Excellence! Employ ME, not my Copycats. **
-- **************************************************

MyLittleSave = {}
local managedNPCs = {}

--- Subscribe to this Module to save the Inventory of an NPC in a custom stash.
---@param newData table The variable containing the NPC's persistent data.
MyLittleSave.ManageNPC = function(newData)
    table.insert(managedNPCs, newData)
end

MyLittleSave.RemoveNPC = function(npcID)
    for i, npcData in ipairs(managedNPCs) do
        if npcID == npcData.uniqueID then
            table.remove(managedNPCs, i)
            break
        end
    end
end

local saveStash = function(npcData)
    if npcData.FirstStart == false then
        local stashSq = MyLittleUtils.FetchRandomSquare(MyLittleUtils.playerObj:getSquare())
        if stashSq then
            npcData.stashCoordsX = stashSq:getX()
            npcData.stashCoordsY = stashSq:getY()
            local stash = IsoObject.new(getCell(), stashSq, "furniture_storage_02_29")
            if stash then
                stashSq:AddSpecialObject(stash)
                stash:getModData().isBravenNPCStash = true
                stash:transmitCompleteItemToClients()
                stash:transmitModData()

                local container = ItemContainer.new()
                stash:setContainer(container)

                local npcInv = npcData.npc:getInventory()
                local itemCount = npcInv:getItems():size()

                for i = itemCount - 1, 0, -1 do
                    local item = npcInv:getItems():get(i)
                    if item then
                        container:AddItem(item)
                    end
                end
            end
        end
    end
end

--- Saves the Stash location of every NPC, no file management needed.
MyLittleSave.OnSave = function(npc)
    if (MyLittleUtils.playerObj and MyLittleUtils.playerObj:getHoursSurvived() <= 0.3) then return end

    if not npc then
        for _, npcData in ipairs(managedNPCs) do
            saveStash(npcData)
        end
    else
        saveStash(npc)
    end

    print("SAVED INVENTORY! SHOW THIS IN BUG REPORTS IF NEEDED!")
end

local onMainMenuMouseDown = MainScreen.onMenuItemMouseDownMainMenu

MainScreen.onMenuItemMouseDownMainMenu = function(item, x, y)
    if MainScreen.instance.inGame == true and item.internal == "EXIT" or item.internal == "QUIT_TO_DESKTOP" then
        MyLittleSave.OnSave()
    end

    onMainMenuMouseDown(item, x, y)
end